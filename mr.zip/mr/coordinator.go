package mr

import (
	"net"
	"net/http"
	"net/rpc"
	"os"
	"strconv"
	"sync"
	"time"
)

type Coordinator struct {
	Status       int        // Current system status
	MapTaskQueue chan *Task // Map task queue
	ReduceQueue  chan *Task // Reduce task queue
	TaskCount    int        // Number of map tasks
	ReducerCount int        // Number of reduce tasks
}

var (
	mutex                     sync.Mutex
	taskMutex                 sync.Mutex
	mapTaskCompleted          map[int]struct{} // Stores whether map tasks are completed
	reduceTaskCompleted       map[int]struct{} // Stores whether reduce tasks are completed
	taskAssignedToWorker      map[int]int      // Stores the worker assigned to a task, -1 if unassigned
	mapTasksCompletedCount    int
	reduceTasksCompletedCount int
)

const (
	MapStatus = iota
	ReduceStatus
	Waiting
	MapWaiting
	ReduceWaiting
	Success
)

func (c *Coordinator) Example(args *ExampleArgs, reply *ExampleReply) error {
	reply.Y = args.X + 1
	return nil
}

func coordinatorSock() string {
	sockName := "/var/tmp/mr-"
	sockName += strconv.Itoa(os.Getuid())
	return sockName
}

func (c *Coordinator) server() {
	rpc.Register(c)
	rpc.HandleHTTP()
	sockName := coordinatorSock()
	os.Remove(sockName)
	listener, err := net.Listen("unix", sockName)
	if err != nil {
		os.Exit(1)
	}
	go http.Serve(listener, nil)
}

func (c *Coordinator) Done() bool {
	done := false
	if mapTasksCompletedCount == c.TaskCount && reduceTasksCompletedCount == c.ReducerCount {
		done = true
		time.Sleep(1 * time.Second)
		os.Exit(0)
	}
	return done
}

func MakeCoordinator(files []string, nReduce int) *Coordinator {
	c := Coordinator{
		Status:       MapStatus,
		TaskCount:    len(files),
		ReducerCount: nReduce,
		MapTaskQueue: make(chan *Task, len(files)),
		ReduceQueue:  make(chan *Task, nReduce),
	}
	mapTaskCompleted = make(map[int]struct{})
	reduceTaskCompleted = make(map[int]struct{})
	taskAssignedToWorker = make(map[int]int)
	c.produceMapTasks(files)
	c.server()
	return &c
}

func (c *Coordinator) SuccessCheck(req *CheckReq, resp *CheckResp) error {
	taskMutex.Lock()
	if taskAssignedToWorker[req.Task] != req.WorkerId {
		taskMutex.Unlock()
		return nil
	}
	if req.Type == MapStatus {
		mapTaskCompleted[req.Task] = struct{}{}
		mapTasksCompletedCount++
	} else if req.Type == ReduceStatus {
		reduceTaskCompleted[req.Task] = struct{}{}
		reduceTasksCompletedCount++
	}
	resp.Success = true
	taskMutex.Unlock()
	return nil
}

func (c *Coordinator) produceMapTasks(files []string) {
	for i, file := range files {
		task := Task{
			Type:         MapStatus,
			ID:           i,
			ReducerCount: c.ReducerCount,
			FileName:     file,
		}
		taskAssignedToWorker[i] = -1
		c.MapTaskQueue <- &task
	}
}
