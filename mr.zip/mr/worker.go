package mr

import (
	"fmt"
	"hash/fnv"
	"io/ioutil"
	"log"
	"math/rand"
	"net/rpc"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"
)

type KeyValue struct {
	Key   string
	Value string
}

func ihash(key string) int {
	h := fnv.New32a()
	h.Write([]byte(key))
	return int(h.Sum32() & 0x7fffffff)
}

func Worker(mapf func(string, string) []KeyValue, reducef func(string, []string) string) {
	rand.Seed(time.Now().UnixNano())
	workerId := rand.Int()

	for true {
		task := CallPullTask(workerId)

		switch task.Type {
		case Success:
			return
		case Waiting:
			time.Sleep(2 * time.Second)
		case MapStatus:
			mapSolve(workerId, mapf, task)
		case ReduceStatus:
			reduceSolve(workerId, reducef, task)
		default:
			return
		}

		time.Sleep(time.Second * 5)
	}
}

func CallExample() {
	args := ExampleArgs{}
	args.X = 99
	reply := ExampleReply{}
	ok := call("Coordinator.Example", &args, &reply)
	if ok {
		// Handle response if needed
	} else {
		// Handle call failure
	}
}

func call(rpcname string, args interface{}, reply interface{}) bool {
	sockName := coordinatorSock()
	c, err := rpc.DialHTTP("unix", sockName)
	if err != nil {
		log.Fatalf("Dialing: %v", err)
	}
	defer c.Close()

	err = c.Call(rpcname, args, reply)
	if err != nil {
		log.Printf("RPC call error: %v", err)
		return false
	}
	return true
}

func CallPullTask(workerId int) Task {
	args := TaskReq{WorkerId: workerId}
	var task Task
	ok := call("Coordinator.PullTask", &args, &task)
	if !ok {
		// Handle call failure
	}
	return task
}

func CallCheck(req CheckReq) {
	resp := CheckResp{}
	ok := call("Coordinator.SuccessCheck", &req, &resp)
	if !ok {
		// Handle call failure
	}
}

func ByKey(kv []KeyValue) {
	sort.Slice(kv, func(i, j int) bool {
		return kv[i].Key < kv[j].Key
	})
}

type KeyValueSlice []KeyValue

func (kv KeyValueSlice) Len() int {
	return len(kv)
}

func (kv KeyValueSlice) Less(i, j int) bool {
	return kv[i].Key < kv[j].Key
}

func (kv KeyValueSlice) Swap(i, j int) {
	kv[i], kv[j] = kv[j], kv[i]
}

func mapSolve(workerId int, mapf func(string, string) []KeyValue, task Task) {
	filename := task.FileName
	file, err := os.Open(filename)
	defer file.Close()
	if err != nil {
		return
	}
	content, err := ioutil.ReadAll(file)
	if err != nil {
		return
	}
	kvSlice := mapf(filename, string(content))
	reduceNum := task.ReducerCount
	hashKv := make([][]KeyValue, reduceNum)
	for _, kv := range kvSlice {
		hashKv[ihash(kv.Key)%reduceNum] = append(hashKv[ihash(kv.Key)%reduceNum], kv)
	}
	for i := 0; i < reduceNum; i++ {
		rand.Seed(time.Now().UnixNano())
		tempFile, err := ioutil.TempFile("", "temp"+strconv.Itoa(rand.Int()))
		if err != nil {
			return
		}
		for _, kv := range hashKv[i] {
			fmt.Fprintf(tempFile, "%v %v\n", kv.Key, kv.Value)
		}
		oldName := tempFile.Name()
		err = os.Rename(oldName, "../"+strconv.Itoa(task.ID)+"-"+strconv.Itoa(i))
		if err != nil {
			tempFile.Close()
			return
		}
		tempFile.Close()
	}
	req := CheckReq{
		Task:     task.ID,
		Type:     task.Type,
		WorkerId: workerId,
	}
	CallCheck(req)
}

func reduceSolve(workerId int, reducef func(string, []string) string, task Task) {
	id := strconv.Itoa(task.ID)
	files, err := ioutil.ReadDir("../")
	if err != nil {
		return
	}
	kv := make([]KeyValue, 0)
	mp := make(map[string][]string)
	for _, fileInfo := range files {
		if !strings.HasSuffix(fileInfo.Name(), id) {
			continue
		}
		file, err := os.Open("../" + fileInfo.Name())
		if err != nil {
			return
		}
		content, err := ioutil.ReadAll(file)
		if err != nil {
			return
		}
		strContent := string(content)
		strSlice := strings.Split(strContent, "\n")
		for _, row := range strSlice {
			kvSlice := strings.Split(row, " ")
			if len(kvSlice) == 2 {
				mp[kvSlice[0]] = append(mp[kvSlice[0]], kvSlice[1])
			}
		}
	}
	for key, value := range mp {
		kv = append(kv, KeyValue{
			Key:   key,
			Value: reducef(key, value),
		})
	}
	rand.Seed(time.Now().UnixNano())
	newFile, err := ioutil.TempFile("", "temp"+strconv.Itoa(rand.Int()))
	if err != nil {
		return
	}
	sort.Sort(KeyValueSlice(kv))
	for _, v := range kv {
		fmt.Fprintf(newFile, "%v %v\n", v.Key, v.Value)
	}
	oldName := newFile.Name()
	defer newFile.Close()
	err = os.Rename(oldName, "mr-out-"+strconv.Itoa(task.ID))
	if err != nil {
		return
	}
	CallCheck(CheckReq{
		Task:     task.ID,
		Type:     task.Type,
		WorkerId: workerId,
	})
}
