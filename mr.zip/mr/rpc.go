package mr

import (
	"time"
)

type TaskReq struct {
	WorkerId int
}

type Task struct {
	Type         int    // System status type
	ID           int    // Task ID
	ReducerCount int    // Number of reducers
	FileName     string // File name
}

type ExampleArgs struct {
	X int
}

type ExampleReply struct {
	Y int
}

type CheckReq struct {
	Task     int // Task ID
	Type     int // Task type
	WorkerId int // Worker ID
}

type CheckResp struct {
	Success bool
}

func (c *Coordinator) makeReduceTasks() {
	for i := 0; i < c.ReducerCount; i++ {
		task := &Task{
			Type:         ReduceStatus,
			ID:           i,
			ReducerCount: c.ReducerCount,
			FileName:     "",
		}
		taskAssignedToWorker[i] = -1
		c.ReduceQueue <- task
	}
}

func (c *Coordinator) PullTask(req *TaskReq, resp *Task) error {
	mutex.Lock()
	defer mutex.Unlock()

	switch c.Status {
	case MapStatus:
		if len(c.MapTaskQueue) > 0 {
			*resp = *<-c.MapTaskQueue
			taskAssignedToWorker[resp.ID] = req.WorkerId
			go func(temp Task) {
				select {
				case <-time.After(10 * time.Second):
					taskMutex.Lock()
					if _, ok := mapTaskCompleted[temp.ID]; !ok {
						c.MapTaskQueue <- &temp
						c.Status = MapStatus
						taskAssignedToWorker[resp.ID] = -1
					}
					taskMutex.Unlock()
				}
			}(*resp)
		} else {
			c.Status = MapWaiting
			resp.Type = Waiting
		}
	case ReduceStatus:
		if len(c.ReduceQueue) > 0 {
			*resp = *(<-c.ReduceQueue)
			resp.Type = ReduceStatus
			temp := *resp
			taskAssignedToWorker[resp.ID] = req.WorkerId
			go func(temp Task) {
				select {
				case <-time.After(10 * time.Second):
					taskMutex.Lock()
					if _, ok := reduceTaskCompleted[temp.ID]; !ok {
						c.ReduceQueue <- &temp
						c.Status = ReduceStatus
						taskAssignedToWorker[temp.ID] = -1
					}
					taskMutex.Unlock()
				}
			}(temp)
		} else {
			c.Status = ReduceWaiting
			resp.Type = Waiting
		}
	case MapWaiting:
		if mapTasksCompletedCount == c.TaskCount {
			c.makeReduceTasks()
			c.Status = ReduceStatus
			resp.Type = Waiting
		} else {
			resp.Type = Waiting
		}
	case ReduceWaiting:
		if reduceTasksCompletedCount == c.ReducerCount {
			c.Status = Success
			resp.Type = Success
		} else {
			resp.Type = Waiting
		}
	default:
		resp.Type = Success
	}
	return nil
}
